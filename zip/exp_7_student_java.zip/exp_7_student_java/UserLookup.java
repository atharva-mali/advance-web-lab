import javax.xml.parsers.*;
import org.w3c.dom.*;

public class UserLookup {
  public static void main(String[] args) throws Exception {
    // Get the User ID from the command line arguments
    int userId = Integer.parseInt(args[0]);

    // Parse the XML document
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    DocumentBuilder db = dbf.newDocumentBuilder();
    Document doc = db.parse("users.xml");

    // Find the User element with the corresponding ID
    NodeList users = doc.getElementsByTagName("user");
    for (int i = 0; i < users.getLength(); i++) {
      Element user = (Element) users.item(i);
      int id = Integer.parseInt(user.getElementsByTagName("id").item(0).getTextContent());
      if (id == userId) {
        // Print the User's information
        String name = user.getElementsByTagName("name").item(0).getTextContent();
        int age = Integer.parseInt(user.getElementsByTagName("age").item(0).getTextContent());
        String email = user.getElementsByTagName("email").item(0).getTextContent();
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Email: " + email);
        break;
      }
    }
  }
}
