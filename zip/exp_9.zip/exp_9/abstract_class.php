<?php

// Abstract class named Shape
abstract class Shape
{
  protected $length;
  protected $width;

  public function __construct($length, $width)
  {
    $this->length = $length;
    $this->width = $width;
  }

  abstract public function printArea();
}

// Rectangle subclass
class Rectangle extends Shape
{
  public function printArea()
  {
    $area = $this->length * $this->width;
    echo "The area of the rectangle is: " . $area . "<br>";
  }
}

// Triangle subclass
class Triangle extends Shape
{
  public function printArea()
  {
    $area = ($this->length * $this->width) / 2;
    echo "The area of the triangle is: " . $area . "<br>";
  }
}

// Circle subclass
class Circle extends Shape
{
  public function printArea()
  {
    $area = pi() * ($this->length ** 2);
    echo "The area of the circle is: " . $area . "<br>";
  }
}

// Instantiate and use the classes
$rectangle = new Rectangle(4, 5);
$rectangle->printArea();

$triangle = new Triangle(3, 6);
$triangle->printArea();

$circle = new Circle(7,null);
$circle->printArea();
?>