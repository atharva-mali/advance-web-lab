<?php

// Define the Shape interface
interface Shape
{
  public function area();
  public function perimeter();
}

// Define the Triangle class that implements Shape
class Triangle implements Shape
{
  private $a, $b, $c;

  public function __construct($a, $b, $c)
  {
    $this->a = $a;
    $this->b = $b;
    $this->c = $c;
  }

  public function area()
  {
    $s = ($this->a + $this->b + $this->c) / 2;
    return sqrt($s * ($s - $this->a) * ($s - $this->b) * ($s - $this->c));
  }

  public function perimeter()
  {
    return $this->a + $this->b + $this->c;
  }
}

// Define the Circle class that implements Shape
class Circle implements Shape
{
  private $radius;

  public function __construct($radius)
  {
    $this->radius = $radius;
  }

  public function area()
  {
    return pi() * pow($this->radius, 2);
  }

  public function perimeter()
  {
    return 2 * pi() * $this->radius;
  }
}

// Create a Triangle object and print its area and perimeter
$triangle = new Triangle(3, 4, 5);
echo "Triangle area: " . $triangle->area() . "<br>";
echo "Triangle perimeter: " . $triangle->perimeter() . "<br>";

// Create a Circle object and print its area and perimeter
$circle = new Circle(5);
echo "Circle area: " . $circle->area() . "<br>";
echo "Circle perimeter: " . $circle->perimeter() . "<br>";
