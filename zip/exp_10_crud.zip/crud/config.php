<?php
    $conn = mysqli_connect("localhost", "root", "", "crud") or die("Couldn't connect to database");
?>